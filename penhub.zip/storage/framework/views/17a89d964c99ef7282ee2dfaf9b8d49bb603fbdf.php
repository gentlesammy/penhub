<?php $__env->startSection('title', 'PenHub: Series Home'); ?>



<?php $__env->startSection('content'); ?>
    <section class="blog-hero">
        <div class="container">
         <h1 class="text-white">SERIES HOME</h1>
         <p>Latest Series</p>
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0">
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/">Home</a></li>
              <li class="breadcrumb-item font-weight-semebold active text-primary" aria-current="page">Series</li>
            </ol>
          </nav>
        </div>
    </section>

    <section class="">
        <div class="container">
            <div class="blogscontainer">
                <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box">
                        <div class="imgpart">
                            <img src="img/series/<?php echo e($ser->feature); ?>" alt="<?php echo e($ser->title); ?>" class="card-img-top rounded-top-0">
                        </div>
                        <div class="textpart">
                            <h4><?php echo e($ser->title); ?></h4>
                            <a href="<?php echo e(Route('blogCategorydetail', ['category'=>$ser->category->id, 'title'=>str_slug($ser->category->title)] )); ?>"><?php echo e($ser->category->title); ?></a> &nbsp;
                            |&nbsp; <a href="<?php echo e(Route('blogseriesdetail', ['id'=>$ser->id, 'title'=>str_slug($ser->title)] )); ?>"><?php echo e($ser->episodes->count()); ?> Episodes</a>
                            <p><?php echo e(str_limit($ser->summary, 200)); ?></p>
                            <p>Author: <a href="#"><?php echo e($ser->user->name); ?></a></p>
                            <p class="text-danger" title="<?php echo e($ser->rating->description); ?>">
                                Rating: <?php echo e($ser->rating->title); ?>

                            </p>
                            <a href="<?php echo e(Route('blogseriesdetail', ['id'=>$ser->id, 'title'=>str_slug($ser->title)] )); ?>">Read Series</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <center>
                <?php echo e($series->links()); ?>

            </center>
        </div>


    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/series/index.blade.php ENDPATH**/ ?>