<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>Edit Rating</h2>


                </div>

                <div class="card-body py-5 my-5">
                   <h4 class="text-center text-primary py-2">Edit Rating: <strong><?php echo e($rating->title); ?></strong></h4>
                <form action="/admin/ratings/edit/<?php echo e($rating->id); ?>-<?php echo e($rating->title); ?>" method="post" class="px-5 mx-5">
                   <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                     <div class="form-group px-5">
                        <label for="exampleFormControlInput1">Rating Title</label>
                     <input type="text" class="form-control"  name="title" value="<?php echo e($rating->title); ?>">
                        <p class="text-danger">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </p>
                      </div>

                      <div class="form-group px-5">
                        <label for="exampleFormControlTextarea1">Rating Description</label>
                        <textarea class="form-control"  rows="3" name="description"><?php echo e($rating->description); ?></textarea>
                        <p class="text-danger">
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </p>
                      </div>

                      <div class="form-group px-5">
                        <button type="submit" class="btn btn-primary">Update Rating</button>
                        <a href="<?php echo e(Route('adRateIndex')); ?>" class="btn btn-danger">Cancel</a>
                      </div>


                   </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views//admin/ratings/edit.blade.php ENDPATH**/ ?>