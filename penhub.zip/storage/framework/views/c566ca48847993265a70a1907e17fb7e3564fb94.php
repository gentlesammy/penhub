<?php $__env->startSection('title', 'PenHub Homepage'); ?>






<?php $__env->startSection('content'); ?>
    <!-- top welcome section-->
    <section class="topsingle">
        <div class="imagesection"> </div>
        <div class="textsection">
            <div class="rowone">
                <p>You are specially Welcome here. We serve it hot, </p>
                <h1>FICTION & NON-FICTION</h1>
                <p>Whatever your appetite is, be it juicy stories or series, short readings or tutorials, simply go to the section and you will have your fill,
                    Myself and guest writers are all at your service.
                </p>
                <a href="/series" class="btn btn-default">VIEW SERIES</a>

            </div>

            <div class="rowtwo">

            </div>

            <div class="rowthree"></div>
        </div>

    </section>
    <!--Major homepage section begins-->


    <section class="majorhome">
        <div class="container">
            <div class="col-2-container">
                <div class="column-8">
                    <!-- series list -->
                    <h2 class="text-center p-bottom mb-5">LATEST SERIES</h2>
                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $se): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ss-box">
                        <div class="img-box" style="max-height:300px; overflow:hidden">
                         <img src="./img/series/<?php echo e($se->feature); ?>" alt="odunlade sam blog">
                        </div>
                        <div class="textbox">
                            <a href="/categories/<?php echo e($se->Category->id); ?>-<?php echo e($se->Category->title); ?>" class="btn-sudo"><?php echo e($se->Category->title); ?></a> &nbsp; Created <?php echo e($se->created_at->format('d M, Y')); ?>

                            <h2><?php echo e($se->title); ?></h2>
                            <p>
                                <?php echo e($se->summary); ?>


                                <a href="/series/<?php echo e($se->id); ?>-<?php echo e(str_slug($se->title)); ?>" class="btnone">Read Series</a>
                            </p>
                            <p class="p-left p-right p-top p-bottom">
                                Warning: <small> <strong><?php echo e($se->Rating->title); ?></strong> &nbsp; <?php echo e($se->Rating->description); ?></small>
                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <!--double story box-->
                    <h2 class="text-center p-bottom mt-5">Latest Episodes</h2>
                    <div class="ds-box epibox">
                        <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $epi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="box ds-box1" style="flex:1;">
                            <div class="img-box" style="height:300px; Overflow:hidden padding:10px;">
                                <img src="./img/episodes/<?php echo e($epi->feature); ?>" alt="odunlade sam blog" class="img img-fluid">
                            </div>
                            <div class="textbox">
                                <a href="/categories/<?php echo e($epi->Series->Category->id); ?>-<?php echo e($epi->Series->Category->title); ?>" class="btn-sudo" title="Category"><?php echo e($epi->Series->Category->title); ?></a> &nbsp; Published: <?php echo e($epi->created_at); ?>

                            <h2><?php echo e($epi->title); ?></h2>
                                <p>
                                    <?php echo e(str_limit($epi->body, 220)); ?>

                                    <a href="<?php echo e(Route('blogEpisodedetail', ['slug'=> $epi->slug])); ?>" class="btnone">Read Episode</a>
                                </p>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <!--static about blogger template. each blogpost will have about its author-->
                <div class="column-4">
                    <div class="searchbox">
                        <input type="text" name="search" id="search">
                        <p>X</p>
                    </div>
                    <div class="img-box">
                        <img src="img/samodunlade.jpeg" alt="">
                    </div>
                    <h3 class="p-left p-top p-bottom">
                        SAM Odunlade,
                        <small> Editor</small>
                    </h3>
                    <p class="p-left p-right p-top p-bottom">
                        Writing has always been my hobby right from the time i finished from primary school in the late 90's.
                        I am also an avid reader with interest in thrillers and suspense filled stories.
                        If you are passionate about good write ups, be it article or stories or even tutorials, you are welcome here
                        we also love good write ups and will even pay for top-quality write ups that get the highest rating every month.
                        If you have opinion about current events, a secret experience you love to share anonymously, hit me up in my inbox
                    </p>
                    <div class="p-left p-top p-bottom p-right">
                    <!--list categories and number -->
                        <h3>Active Categories</h3>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="display:flex; flex-direction:row; justify-content:space-between; align-items:center">
                            <a href="/categories/<?php echo e($cat->category_id); ?>-<?php echo e(App\Category::getCategoryname($cat->category_id)); ?>" style="flex:1"><?php echo e(App\Category::getCategoryname($cat->category_id)); ?></a> &nbsp; <span class="badge badge-primary badge-pill" ><?php echo e($cat->category_count); ?></span></p>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="p-left p-top p-bottom p-right shortepisodebox">
                        <h3>Latest Episodes</h3>
                        <?php $__currentLoopData = $episodesall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $epi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(Route('blogEpisodedetail', ['slug'=>$epi->slug])); ?>">
                                <div class="box">

                                    <img src="./img/episodes/<?php echo e($epi->feature); ?>" alt="odunlade sam blog" class="img img-fluid">

                                    <div class="textfield">
                                        <p class="lead text-left"><?php echo e(str_limit($epi->title, 20)); ?></p>
                                        <p class="text-left">
                                            <?php echo e(str_limit($epi->body, 50)); ?>


                                        </p>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="p-left p-top p-bottom p-right shortepisodebox">
                        <h3>Latest Profiles</h3>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="box">

                                    <img src="img/profile/<?php echo e($pro->image); ?>" alt="odunlade sam blog writers" class="img img-fluid">

                                    <div class="textfield">
                                        <p class="lead text-left"><?php echo e(str_limit($pro->username, 20)); ?></p>
                                        <p class="text-left">
                                            <?php echo e(str_limit($pro->description, 100)); ?>


                                        </p>
                                    </div>
                                </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                </div>
            </div>

        </div>


    </section>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/index.blade.php ENDPATH**/ ?>