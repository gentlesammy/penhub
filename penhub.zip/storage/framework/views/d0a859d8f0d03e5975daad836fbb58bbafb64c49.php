<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>USER DETAIL</h2>
                    <p>***Note: You can Promote/Demote Current User Here</p>
                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- user details and profile details goes here when i update profile table-->

                        </div>

                        <div class="col-md-6">
                            <!--user upgrade/downgrade form goes here -->
                            <form action="/admin/users/view/<?php echo e($user->id); ?>" method="post">
                                <?php echo method_field('patch'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Current Rank')); ?></label>

                                    <div class="col-md-6">
                                    <input id="text" type="text" class="form-control" name="role" value="<?php echo e($user->getUserRank($user->role)); ?>" disabled>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>

                                    <div class="col-md-6">
                                        <select name="role" id="" class="form-control">
                                            <option value="1">Reader</option>
                                            <option value="2">Writer</option>
                                            <option value="3">Moderator</option>
                                            <option value="4">Admin</option>
                                        </select>

                                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input type="submit" value="Promote" class="btn-primary form-control">
                                </div>




                            </form>
                        </div>




                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/users/view.blade.php ENDPATH**/ ?>