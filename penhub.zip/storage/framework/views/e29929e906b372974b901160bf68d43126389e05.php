<?php $__env->startSection('title', 'PenHub'. $id->title); ?>



<?php $__env->startSection('content'); ?>
    <section class="blog-hero">
        <div class="container">
         <h1 class="text-white"><?php echo e($id->title); ?></h1>
        <?php if(auth()->guard()->check()): ?>
            <button class="btnone followseries" data-user_id="<?php echo e(auth()->user()->id); ?>" data-series_id="<?php echo e($id->id); ?>">Follow</button>
        <?php endif; ?>
         <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" id="metadaddy">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0 my-2">
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/">Home</a></li>
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/series">Series</a></li>
              <li class="breadcrumb-item font-weight-semebold active text-primary" aria-current="page"><?php echo e($id->title); ?></li>
            </ol>
          </nav>
        </div>
    </section>

    <section class="seriesdetail">
        <div class="container">
            <div class="barcontainers">
                <div class="mainbar">
                    <div class="row1">
                        <div class="imagearea">
                            <img src="/img/series/<?php echo e($id->feature); ?>" alt="<?php echo e($id->title); ?>" class="card-img-top rounded-top-0">
                        </div>
                        <div class="summaryarea">
                            <h5>Summary</h5>
                            <p>
                                <?php echo e($id->summary); ?>

                            </p>
                            <p><strong>Author: </strong> <?php echo e($id->user->name); ?></p>
                            <p>
                             <strong>Published: </strong>  <?php echo e($id->created_at->format('D, d M Y')); ?>

                            </p>
                        </div>
                    </div>
                    <h5 class="text-center my-2">EPISODES In order of Recent</h5>
                    <div class="rowb">
                        <?php if($episodes->count()>0): ?>
                            <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="row2">
                                    <div class="imagearea">
                                        <img src="/img/episodes/<?php echo e($episode->feature); ?>" alt="<?php echo e($episode->title); ?>" class="card-img-top rounded-top-0">
                                    </div>
                                    <div class="summaryarea">
                                        <h5><?php echo e($episode->title); ?></h5>
                                        <p class="text-justify">
                                            <?php echo e(str_limit($episode->body, 200)); ?>

                                        </p>
                                        <p>
                                        <strong>Published: </strong>  <?php echo e($episode->created_at->format('D, d M Y')); ?>

                                        </p>

                                        <a href="<?php echo e(Route('blogEpisodedetail', $episode->slug)); ?>">Read Episode</a>
                                    </div>
                                 </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($episodes->links()); ?>

                        <?php else: ?>
                            <p class="text-center py-5 bg-white">This series does not contained published episode for now</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="sidebar">
                    <div class="row1">
                        <h5 class="text-center">About Author</h5>
                        <!--if author is not anon -->
                        <?php if($id->user->profile->anonymous != 1): ?>
                            <img src="/img/profile/<?php echo e($id->user->profile->image); ?>" alt="<?php echo e($id->user->profile->username); ?>" class="img img-fluid p-2">
                            <h6 class="text-center"><?php echo e($id->user->profile->username); ?></h6>
                            <?php if($id->user->profile->showsocial == 1): ?>
                            <ul class="social-links list unstyle">
                                <li><a href="<?php echo e($id->user->profile->facebook); ?>" target="_new"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($id->user->profile->twitter); ?>" target="_new"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            </ul>
                            <p class="text-justify">
                                <?php echo e($id->user->profile->description); ?>

                            </p>
                            <?php endif; ?>

                        <?php else: ?>
                            <!--if author is  anon -->
                            <img src="/img/defaultprofile.png" alt="penhub default profile" class="img img-fluid p-2">
                            <h6 class="text-center">Anonymous</h6>
                            <p class="text-justify">
                                The author of this article has choosen the anonymous option, this means their
                                picture, social media handle and phone number will not be displayed. You can however
                                send them message through our platform messanger.
                            </p>
                        <?php endif; ?>
                    </div>

                    <div class="row2">
                        <h5 class="text-center">Other Series By Author</h5>

                            <?php if($id->user->series->count()>0): ?>
                            <!-- author has other series -->
                                <?php $__currentLoopData = $id->user->series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(Route('blogseriesdetail', ['id'=>$item->id, 'title'=>str_slug($item->title)])); ?>"><?php echo e($item->title); ?></a>
                                    <p><?php echo e(str_limit($item->summary, 50)); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-justify">Non is available at the moment </p>
                            <?php endif; ?>




                    </div>






                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    window.addEventListener('DOMContentLoaded', function(){
        const ff = document.querySelector('.followseries');
    ff.addEventListener('click', (e)=>{
        e.preventDefault();
        //Select token with getAttribute
        let token = document.querySelector("#metadaddy").getAttribute("content");
        let user_id = document.querySelector(".followseries").dataset.user_id;
        let series_id = document.querySelector(".followseries").dataset.series_id;
        alert (user_id);
        //action when button is clicked
                fetch('/series/follow/'+ user_id, {
                            headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json, text-plain, */*",
                            "X-Requested-With": "XMLHttpRequest",
                            "X-CSRF-TOKEN": token
                            },
                            method: 'post',
                            credentials: "same-origin",
                            body: JSON.stringify({
                                user_id: user_id,
                                series_id:series_id
                            })
                            })
                            .then((response) => {
                                return response.json();
                            })
                            .then((myJson) => {
                                console.log(myJson);
                            })
                 .catch(function(error) {
                                console.log(error);
                                });
    });
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/series/detail.blade.php ENDPATH**/ ?>