<?php $__env->startSection('title', 'Penhub: About Us'); ?>











<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="row">
           <div class="col-md-6 bg-primary text-white text-center pt-5" style="position:relative;">
            <div class="imgcont" style="width:300px; height:300px; border-radius:50%; overflow:hidden;box-shadow: 0px 10px 14px 0px rgba(0, 0, 0, 0.25)">
                <img src="img/samodunladeOpeyemi.jpeg" alt="" class="" >
                <p>My Queen.. my world</p>
                <p>I LOVE YOU BABY</p>
            </div>
            <div>
                    <h1 class="text-center">OPEYEMI MI OWON</h1>
            <p>I just want to tell you that i missssss you,
                i cant wait to see you back at home
                kisseeeeeeeeeeeeeeeesssssssssssssss
            </p>
            <p class="pb-5">
                And By the way, it feels like a year that i have seen u last....
            </p>
            </div>

           </div>

       </div>
   </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/about.blade.php ENDPATH**/ ?>