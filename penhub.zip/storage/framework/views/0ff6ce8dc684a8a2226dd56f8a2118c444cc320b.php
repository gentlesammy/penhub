


<?php echo e(($comment->body)); ?>

<form action="/admin/comments/remove/<?php echo e($comment->id); ?>" method="post">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <input type="submit" name="delete" id="deletecombtn" class="btn" value="Delete">
</form>
<?php if($comment->approved == 0): ?>
    <form action="/admin/comments/aprove/<?php echo e($comment->id); ?>" method="post">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <input type="submit" name="aprove" id="appcombtn" class="btn" value="Aprrove comment">
    </form>
<?php else: ?>
    <form action="/admin/comments/unaprove/<?php echo e($comment->id); ?>" method="post">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <input type="submit" name="unaprove" id="appcombtn" class="btn" value="Dissaprrove comment">
    </form>
<?php endif; ?>






<?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/comments/view.blade.php ENDPATH**/ ?>