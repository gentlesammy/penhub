<div class="sidelinks">
    <ul class="navbar-nav mr-auto">
        <li><a href="<?php echo e(Route('adCatIndex')); ?>">Categories</a></li>
        <li><a href="<?php echo e(Route('adRateIndex')); ?>">Ratings</a></li>
        <li><a href="<?php echo e(Route('adseriesIndex')); ?>">Series</a></li>
        <li><a href="<?php echo e(Route('adEpisodesIndex')); ?>">Episodes</a></li>
        <li><a href="<?php echo e(Route('adCommentsIndex')); ?>">Comments</a></li>
        <li><a href="<?php echo e(Route('adSubscribersIndex')); ?>">Subscribers</a></li>
    <li><a href="<?php echo e(Route('adUsersIndex')); ?>">Users</a></li>
        <li><a href="<?php echo e(Route('adMessagesIndex')); ?>">Messages</a></li>
    </ul>

        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>


</div>
<?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/include/adminnav.blade.php ENDPATH**/ ?>