<footer>
        <div class="container">


            <div class="falsefooter">
                <div class="copy box">
                    <h6>Copyright Statement</h6>
                    <p>
                        All content of this website is the copyright of their writers,
                        None of it can be copied in any form by any means without the
                        consent of the writer which can be gotten through us. Transgressor will be duly
                        prosecuted in the court of law.
                    </p>
                </div>
                <div class="newsletter box">
                    <h6>Subscribe Now</h6>
                    <p>
                        Get latest Series and Episodes notification in your email. Be the first to read
                        all our juicy publications.
                        <form action="" method="post">
                            <input type="text" placeholder="example@email.com" class="form-control">
                        </form>
                    </p>

                </div>
                <div class="sociallinks box">

                    <h6>Follow Us</h6>
                    <p>Get Our Posts Regularly through our social platforms</p>
                    <ul class="social-links list unstyle">
                        <li><a href="https://web.facebook.com/penhubng" target="_new"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/hub_pen" target="_new"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li class="social-link"><a href="https://www.instagram.com/penhubng" target="_new"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                        <li class="social-link"><a href="https://wa.me/2348060913903?text=official%20message"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>

        </div>
        <div class="copyright">
            <p>Copyright <?php echo e(Date('Y')); ?> All Rights Reserved | Powered By Sayem Technologies</p>
        </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/include/blogfooter.blade.php ENDPATH**/ ?>