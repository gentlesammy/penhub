<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>All Categories</h2>
                <a href="<?php echo e(Route('adCreateCat')); ?>" class="btn btn-primary btn-sm">CREATE CATEGORY</a>
                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td>CATEGORY NAME</td>
                                <td>CATEGORY DESCRIPTION</td>
                                <td>ACTION</td>

                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($sn ++); ?></td>
                            <td><?php echo e($category->title); ?></td>
                            <td><?php echo e($category->description); ?></td>
                            <td>
                                <a href="/admin/categories/detail/<?php echo e($category->id); ?>-<?php echo e($category->title); ?>" class="btn btn-sm btn-info">D</a>
                                <a href="/admin/categories/edit/<?php echo e($category->id); ?>-<?php echo e($category->title); ?>" class="btn btn-sm btn-primary">E</a>

                                <form action="/admin/categories/delete/<?php echo e($category->id); ?>" method="post" class="py-2">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>




                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>