<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>ALL EPISODES</h2>
                <a href="<?php echo e(Route('adEpisodesCreate')); ?>" class="btn btn-primary btn-sm">CREATE EPISODE</a>
                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td>Episode TITLE</td>
                                <td style="width: 40%;">Episode body</td>
                                <td>Series Title</td>
                                <td>Published</td>
                                <td style="width: 10%;">Action</td>

                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>
                            <?php if($episodes->count() >0): ?>
                                <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($sn++); ?></td>
                                    <td><?php echo e($episode->title); ?></td>
                                    <td><?php echo e(substr($episode->body, 0, 100)); ?></td>
                                    <td><?php echo e($episode->Series->title); ?></td>
                                    <td>
                                        <?php if($episode->published ===0): ?>
                                            Unpublished
                                        <?php else: ?>
                                            Published
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                    <a href="/admin/episodes/view/<?php echo e($episode->slug); ?>" class="btn btn-sm btn-link">Detail</a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $episode->series)): ?>
                                            &nbsp;
                                            <a href="/admin/episodes/edit/<?php echo e($episode->id); ?>-<?php echo e(str_slug($episode->title)); ?>" class="btn btn-sm btn-link my-2">Edit</a>

                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $episode->series)): ?>
                                            <?php if($episode->published ===0): ?>
                                                &nbsp;
                                                 <a href="/admin/episodes/publish/<?php echo e($episode->id); ?>-<?php echo e(str_slug($episode->title)); ?>" class="btn btn-sm btn-link my-2">Publish</a>
                                             <?php else: ?>
                                             &nbsp;
                                             <a href="/admin/episodes/unpublish/<?php echo e($episode->id); ?>-<?php echo e(str_slug($episode->title)); ?>" class="btn btn-sm btn-link my-2">Unpublish</a>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </td>
                                    </tr>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>

                                <h3 class="text-center text-danger py-5">No Series Available currently</h3>

                            <?php endif; ?>



                        </tbody>




                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/episodes/index.blade.php ENDPATH**/ ?>