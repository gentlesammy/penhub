<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>ALL SUBSCRIBERS</h2>
                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td>Name</td>
                                <td style="width: 40%;">Email</td>
                                <td>Status</td>
                                <td style="width: 10%;">Payment</td>
                                <td style="width: 10%;">Action</td>

                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>
                            <?php if($subscribers->count() >0): ?>
                                        <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($sn++); ?></td>
                                                <td><?php echo e($subscriber->name); ?></td>
                                                <td><?php echo e($subscriber->email); ?></td>
                                                <td>
                                                    <?php if($subscriber->active == 0): ?>
                                                    Inactive
                                                    <?php else: ?>
                                                     Active
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($subscriber->paid == 0): ?>
                                                        <form action="/admin/subscribers/paid/<?php echo e($subscriber->id); ?>" method="post">
                                                            <?php echo method_field('PATCH'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit" name="paid" class="btn btn-primary btn-sm" value="Pay">
                                                        </form>
                                                    <?php else: ?>
                                                    Paid
                                                    <?php endif; ?>



                                                </td>
                                                <td>
                                                    <?php if($subscriber->active==0): ?>
                                                        <form action="/admin/subscribers/activate/<?php echo e($subscriber->id); ?>" method="post">
                                                            <?php echo method_field('PATCH'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit"  class="btn btn-primary btn-sm" value="Activate">
                                                        </form>
                                                    <?php else: ?>
                                                        <form action="/admin/subscribers/deactivate/<?php echo e($subscriber->id); ?>" method="post">
                                                            <?php echo method_field('PATCH'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit"  class="btn btn-primary btn-sm" value="Deactivate">
                                                        </form>
                                                    <?php endif; ?>
                                                </td>

                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e($subscribers->links()); ?>

                            <?php else: ?>

                                <h3 class="text-center text-danger py-5">No Series Available currently</h3>

                            <?php endif; ?>



                        </tbody>





                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
























<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/subscribers/index.blade.php ENDPATH**/ ?>