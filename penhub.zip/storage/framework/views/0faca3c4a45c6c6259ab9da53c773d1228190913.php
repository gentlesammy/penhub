<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center align-content align-content-center justify-content-center">
                    <h2>Archieved MESSAGES <span class="badge badge-dark badge-pill"><?php echo e($archievedmessages->count()); ?></span></h2>
                    <a href="<?php echo e(Route('adMessagesIndex')); ?>">UnRead Messages</a> &nbsp;
                    &nbsp;<a href="<?php echo e(Route('adReadMessagesIndex')); ?>">Read Messages</a>

                    <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td>Sender</td>
                                <td>Phone</td>
                                <td style="width: 40%;">Message</td>
                                <td>Date</td>
                                <td style="width: 10%;">Action</td>
                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>
                            <?php if($archievedmessages->count() >0): ?>
                                        <?php $__currentLoopData = $archievedmessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e($sn++); ?></td>
                                            <td><?php echo e($msg->name); ?></td>
                                            <td><?php echo e($msg->phone); ?></td>
                                            <td><?php echo e($msg->messages); ?></td>
                                            <td><?php echo e($msg->created_at); ?></td>
                                            <td>
                                            <a href="delete/<?php echo e($msg->id); ?>-<?php echo e(str_slug($msg->name)); ?>" class="btn btn-danger">Delete</a>
                                            </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e($archievedmessages->links()); ?>

                            <?php else: ?>

                                <h3 class="text-center text-danger py-5">No  Messages in  Archieve</h3>

                            <?php endif; ?>



                        </tbody>





                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


























<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/messages/archievedmessages.blade.php ENDPATH**/ ?>