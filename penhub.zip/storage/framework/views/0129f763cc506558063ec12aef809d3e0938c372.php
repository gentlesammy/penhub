<div class="navbar">
    <ul class="nav">

    <li><a href="<?php echo e(Route('about')); ?>">About</a></li>
        <li><a href="<?php echo e(Route('blogserieshome')); ?>">Series</a></li>
        <li><a href="<?php echo e(Route('blogEpisodehome')); ?>">Episodes</a></li>
        <li><a href="<?php echo e(Route('writeforus')); ?>">Write for Us </a></li>
        <li><a href="<?php echo e(Route('contact')); ?>">Contact</a></li>
    </ul>
    <div class="sociallink">

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/include/blognav.blade.php ENDPATH**/ ?>