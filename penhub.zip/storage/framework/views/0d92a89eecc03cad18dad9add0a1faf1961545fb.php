<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>ALL Users</h2>
                    <p>***Note: You can only see Users below you in Rank</p>
                <a href="/admin/users" class="btn btn-primary btn-sm">All Users</a> &nbsp;
                <a href="/admin/users/?muted=1" class="btn btn-primary btn-sm">muted Users</a> &nbsp;
                <a href="/admin/users/?blocked=1" class="btn btn-primary btn-sm">Blocked Users</a> &nbsp;
                <a href="/admin/users/?role=3" class="btn btn-primary btn-sm">Moderators</a> &nbsp;
                <a href="/admin/users/?role=2" class="btn btn-primary btn-sm">Writers</a> &nbsp;
                <a href="/admin/users/?role=1" class="btn btn-primary btn-sm">Readers </a> &nbsp;

                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td style="width: 40%;">Name</td>
                                <td>Email</td>
                                <td>Post</td>
                                <td>Muted</td>
                                <td>Blocked</td>
                                <td>Joined</td>
                                <td>Series </td>
                                <td style="width: 10%;">Action</td>

                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>
                            <?php if($users->count() >0): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sn++); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <?php echo e(\App\User::getUserRank($user->role)); ?>

                                        </td>
                                        <td class="text-center">
                                            <?php if($user->muted ===0): ?>
                                                No
                                                <a href="<?php echo e(Route('adMuteUsers', $user->id)); ?>" class="btn btn-danger">Mute</a>
                                            <?php else: ?>
                                                Yes
                                                <a href="<?php echo e(Route('adUnmuteUsers', $user->id)); ?>" class="btn btn-primary">Unmute</a>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($user->blocked ===0): ?>
                                                No
                                                <a href="<?php echo e(Route('adBlockUsers', $user->id)); ?>" class="btn btn-danger">Block</a>
                                            <?php else: ?>
                                                Yes
                                                <a href="<?php echo e(Route('adUnblockUsers', $user->id)); ?>" class="btn btn-primary">Unbock</a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($user->created_at); ?>

                                        </td>
                                        <td>

                                        </td>

                                        <td class="text-center">
                                            Edit
                                            <a href="/admin/users/view/<?php echo e($user->id); ?>" class="btn btn-primary">Detail</a>
                                        </td>




                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>

                                <h3 class="text-center text-danger py-5">Empty</h3>

                            <?php endif; ?>



                        </tbody>




                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/users/index.blade.php ENDPATH**/ ?>