<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>Edit Category</h2>


                </div>

                <div class="card-body py-5 my-5">
                   <h4 class="text-center text-primary py-2">Edit Category: <strong><?php echo e($category->title); ?></strong></h4>
                <form action="/admin/categories/edit/<?php echo e($category->id); ?>-<?php echo e($category->title); ?>" method="post" class="px-5 mx-5">
                   <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                     <div class="form-group px-5">
                        <label for="exampleFormControlInput1">Category Title</label>
                     <input type="text" class="form-control"  name="title" value="<?php echo e($category->title); ?>">
                        <p class="text-danger">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </p>
                      </div>

                      <div class="form-group px-5">
                        <label for="exampleFormControlTextarea1">Category Description</label>
                        <textarea class="form-control"  rows="3" name="description"><?php echo e($category->description); ?></textarea>
                        <p class="text-danger">
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </p>
                      </div>

                      <div class="form-group px-5">
                        <button type="submit" class="btn btn-primary">Update Category</button>
                      </div>


                   </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views//admin/categories/edit.blade.php ENDPATH**/ ?>