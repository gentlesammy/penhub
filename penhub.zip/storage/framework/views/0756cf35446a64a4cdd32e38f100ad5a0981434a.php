<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- title yield-->
    <title><?php echo $__env->yieldContent('title', "Sam Odun's PenPoint"); ?></title>
    <!-- description yield-->
    <?php echo $__env->yieldContent('description'); ?>

     <!-- keyword yield-->
     <?php echo $__env->yieldContent('keyword'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
     <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/blog.css')); ?>" rel="stylesheet">
</head>
<body>
    <!-- navbar  section-->
    <section class="navarea">
        <div class="nav-title">
        <a href="<?php echo e(Route('blogindex')); ?>" class="title"> PenHub    <span>| Pen Aflame</span></a>
            <div class="hamburger">
                <span class="icon-bar" id="bar1"></span>
                <span class="icon-bar" id="bar2"></span>
                <span class="icon-bar" id="bar3"></span>
            </div>
        </div>
        <?php echo $__env->make('include.blognav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <!-- content section -->
    <?php echo $__env->yieldContent('content'); ?>







    <?php echo $__env->make('include.blogfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="<?php echo e(asset('js/blog.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/layouts/blog.blade.php ENDPATH**/ ?>