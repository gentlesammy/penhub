<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2> <small><?php echo e($episodes->title); ?></small></h2>
                    <p class="lead">SERIES: <small><?php echo e($episodes->Series->title); ?> </small></p>
                    <p class=""><small><?php echo e($episodes->created_at->diffForHumans()); ?> </small></p>

                </div>

                <div class="card-body">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-md-6">
                            <p class="lead">SUMMARY</p>
                            <p class="text-justify"><?php echo e($episodes->body); ?></p>
                            <p class="lead">AUTHOR: <small><?php echo e($episodes->Series->User->name); ?> </small></p>
                            <p class="lead">STATUS:
                            <small>
                                <?php if($episodes->published === 0): ?>
                                    Unpublished
                                <?php else: ?>
                                    Published
                                <?php endif; ?>

                            </small></p>



                        </div>
                        <div class="col-md-6">
                            <img src="/img/episodes/<?php echo e($episodes->feature); ?>" alt="<?php echo e($episodes->slug); ?>" class="img img-fluid justify-content-center align-items-center">
                        <a href="<?php echo e(Route('adEpisodesIndex')); ?>" class="btn btn-primary btn-block btn-lg my-5">Back</a>
                        </div>
                    </div>


                <div class="row">



                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/episodes/view.blade.php ENDPATH**/ ?>