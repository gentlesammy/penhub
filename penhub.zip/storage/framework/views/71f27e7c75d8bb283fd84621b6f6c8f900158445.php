<?php $__env->startSection('title', 'PenHub'); ?>



<?php $__env->startSection('content'); ?>
    <section class="blog-hero">
        <div class="container">
         <h1 class="text-white"><?php echo e($episode->series->title); ?></h1>
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0 my-2">
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/">Home</a></li>
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/series">Series</a></li>
              <li class="breadcrumb-item font-weight-semebold active text-primary" aria-current="page"><?php echo e($episode->title); ?></li>
            </ol>
          </nav>
        </div>
    </section>


    <section class="epidetail">
        <div class="container">
            <div class="episodebox">

                    <div class="episode">
                        <div class="img-box">
                             <img src="/img/episodes/<?php echo e($episode->feature); ?>" alt="$episode->title" class="img-responsive">
                        </div>
                        <p class="my-2">By <strong><?php echo e($episode->series->user->name); ?></strong> / On <?php echo e($episode->created_at->format('d M, Y')); ?></p>
                        <h2><?php echo e($episode->title); ?></h2>

                        <p class="story">
                            <?php echo e($episode->body); ?>

                        </p>
                        <p class="text-center lead">Share <span> <i class="fa fa-share" aria-hidden="true"></i>    </span></p>
                        <ul class="social-links list unstyle">
                            <li><a href="http://facebook.com/psalmsam" target="_new"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="https://twitter.com/gentlesammy84" target="_new"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li class="social-link"><a href="https://www.instagram.com/psalmsam84/?hl=en" target="_new"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            <li class="social-link"><a href="https://wa.me/2348060913903?text=official%20message"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <!--This div includes the author and other sidebar features -->
                    <div class="author">
                        <!--if author is not anon -->
                        <?php if($episode->series->user->profile->anonymous != 1): ?>
                            <img src="/img/profile/<?php echo e($episode->series->user->profile->image); ?>" alt="<?php echo e($episode->series->user->profile->username); ?>" class="img img-fluid p-2">
                            <h6 class="text-center"><?php echo e($episode->series->user->profile->username); ?></h6>
                            <?php if($episode->series->user->profile->showsocial == 1): ?>
                            <ul class="social-links list unstyle">
                                <li><a href="<?php echo e($episode->series->user->profile->facebook); ?>" target="_new"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($episode->series->user->profile->twitter); ?>" target="_new"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            </ul>
                            <p class="text-justify">
                                <?php echo e($episode->series->user->profile->description); ?>

                            </p>
                            <?php endif; ?>

                        <?php else: ?>
                            <!--if author is  anon -->
                            <img src="/img/defaultprofile.png" alt="penhub default profile" class="img img-fluid p-2">
                            <h6 class="text-center">Anonymous</h6>
                            <p class="text-justify">
                                The author of this article has choosen the anonymous option, this means their
                                picture, social media handle and phone number will not be displayed. You can however
                                send them message through our platform messanger.
                            </p>
                        <?php endif; ?>
                            <h5>Other Episodes</h5>
                        <?php $__currentLoopData = $relatedepisode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($reep->slug); ?>"><?php echo e($reep->title); ?></a>
                                <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="commentbox">
                        <h5>LATEST COMMENTS (<?php echo e($comments->count()); ?>)</h5>
                        <?php if($comments->count() > 0): ?>
                            <!--list of available comments -->
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="commentboxx">
                                    <div class="userimgarea">
                                        <?php if($comment->user->profile): ?>
                                            <img src="/img/profile/<?php echo e($comment->user->profile->image ?? 'defaultprofile.png'); ?>" alt="<?php echo e($comment->user->profile->name); ?>" class="img img-fluid">
                                        <?php else: ?>
                                            <img src="/img/profile/defaultprofile.png" alt="" class="img img-fluid">
                                        <?php endif; ?>
                                    </div>
                                    <div class="textarea">
                                        <h6 class="commentername"> <?php echo e(strtoupper($comment->user->name)); ?></h6>
                                        <h6 class="commentertime"> <?php echo e($comment->created_at->format('d M Y')); ?> At <?php echo e($comment->created_at->format('H:i a')); ?></h6>
                                        <p class="comment" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $comment)): ?> contenteditable="true" <?php endif; ?>><?php echo e($comment->body); ?></p>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $comment)): ?>
                                            <button class="btn btn-danger">
                                                Delete Comment
                                            </button>
                                        <?php endif; ?>

                                    </div>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                        <?php else: ?>
                            <p>No comment on this Episode Currently. Add comment below</p>
                        <?php endif; ?>

                    </div>
                    <div class="commentform">
                        <?php if(auth()->user()): ?>

                            <?php if(auth()->user()->muted == 1): ?>
                                <p>You are currently muted. You cant comment</p>
                            <?php else: ?>
                                <p>Comment form</p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <h1>

                    </h1>


            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<!--
     <div class="linksepi">
                    <?php echo e($relatedepisode->links()); ?>

                </div>
-->

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/episodes/detail.blade.php ENDPATH**/ ?>