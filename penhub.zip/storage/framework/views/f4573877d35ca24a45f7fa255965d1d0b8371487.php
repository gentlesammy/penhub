<?php $__env->startSection('title', 'PenHub: Latest Episode '); ?>
<?php $__env->startSection('description'); ?>
<meta name="description" content="Penhub: All the latest episodes of your award winning series can be found here.">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="blog-hero">
        <div class="container">
         <h1 class="text-white">Latest Episodes</h1>
         <p>Latest published Episodes</p>
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent p-0">
              <li class="breadcrumb-item font-weight-semebold"><a class="text-white" href="/">Home</a></li>
              <li class="breadcrumb-item font-weight-semebold active text-primary" aria-current="page">Episodes</li>
            </ol>
          </nav>
        </div>
    </section>

    <section class="episodehome">
        <div class="container">

            <div class="boxcontainer">
                <div class="main">
                    <?php if($episodes->count()>0): ?>
                        <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $epi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--each episode detail -->
                            <div class="box">
                                <div class="img-container">
                                    <img src="img/episodes/<?php echo e($epi->feature); ?>" alt="<?php echo e($epi->title); ?>" class="img-fluid">
                                </div>
                                <div class="detailbox">
                                    <h5><?php echo e($epi->title); ?></h5>
                                    <p class="published">Published: <?php echo e($epi->created_at->format('d M, Y')); ?></p>
                                    <p class="series">Series: <a href="<?php echo e(Route('blogseriesdetail', ['id'=>$epi->series->id, 'title'=>str_slug($epi->series->title)] )); ?>"><?php echo e($epi->series->title); ?></a></p>
                                    <p class="summary"><?php echo e(str_limit($epi->body, 100)); ?></p>
                                    <a href="<?php echo e(Route('blogEpisodedetail', $epi->slug)); ?>" class="btn btn-link">Read Episode</a>

                                </div>
                            </div>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>
                            No published Episode is available currently
                        </p>
                    <?php endif; ?>
                </div>
                <div class="sidebar">
                    <div class="boxone">
                        <h5>Active Series</h5>
                        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="display:flex; flex-direction:row; justify-content:space-between; align-items:center"><a href="<?php echo e(Route('blogseriesdetail', ['id'=>$ser->series_id, 'title'=>str_slug(App\Series::getSeriesname($ser->series_id))] )); ?>" style="flex:1"><?php echo e(App\Series::getSeriesname($ser->series_id)); ?></a> &nbsp; <span class="badge badge-primary badge-pill" ><?php echo e($ser->series_count); ?></span></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="boxtwo">
                        <h5>Categories</h5>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="display:flex; flex-direction:row; justify-content:space-between; align-items:center"><a href="#" style="flex:1"><?php echo e(App\Category::getCategoryname($cat->category_id)); ?></a> &nbsp; <span class="badge badge-primary badge-pill" ><?php echo e($cat->category_count); ?></span></p>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="paginatelinks">
                    <?php echo e($episodes->links()); ?>

                </div>

            </div>

        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/blog/episodes/index.blade.php ENDPATH**/ ?>