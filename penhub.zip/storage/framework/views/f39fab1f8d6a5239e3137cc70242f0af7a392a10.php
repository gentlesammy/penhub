<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2> Category Detail</h2>


                </div>

                <div class="card-body">
                <h4 class="text-center text-primary"><?php echo e($category->title); ?></h4>
                <p class="text-md-center text-black-50"><?php echo e($category->description); ?></p>

                <div class="row">

                    <?php $__currentLoopData = $catseries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                            <h2><?php echo e($item->title); ?></h2>
                           <p class="text-justify"> <?php echo e($item->summary); ?> </p>
                            <img src="/img/series/<?php echo e($item->feature); ?>" alt="<?php echo e($item->title); ?>" class="img img-fluid">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/categories/view.blade.php ENDPATH**/ ?>