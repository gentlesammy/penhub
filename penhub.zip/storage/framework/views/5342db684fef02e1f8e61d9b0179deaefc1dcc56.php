<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2> Series Detail: <small><?php echo e($series->title); ?></small></h2>
                    <p class="lead">CATEGORY: <small><?php echo e($series->Category->title); ?> </small></p>
                    <p class=""><small><?php echo e($series->created_at->diffForHumans()); ?> </small></p>

                </div>

                <div class="card-body">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-md-6">
                            <p class="lead">SUMMARY</p>
                            <p class="text-justify"><?php echo e($series->summary); ?></p>
                            <p class="lead">AUTHOR: <small><?php echo e($series->User->name); ?> </small></p>
                            <p class="lead">STATUS:
                            <small>
                                <?php if($series->active === 0): ?>
                                    Inactive
                                <?php else: ?>
                                    Active
                                <?php endif; ?>

                            </small></p>
                            <p class="lead">Rating: <small><?php echo e($series->Rating->title); ?> </small></p>


                        </div>
                        <div class="col-md-6">
                            <img src="/img/series/<?php echo e($series->feature); ?>" alt="<?php echo e($series->title); ?>" class="img img-fluid justify-content-center align-items-center">
                        </div>
                    </div>


                <div class="row">



                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/series/view.blade.php ENDPATH**/ ?>