<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2>ALL COMMENTS</h2>
                <?php if(Session::has('flash_message')): ?>
                <div class="alert <?php echo e(Session::get('flash_type')); ?> mx-5 px-5 mt-3">
                    <h3 class=""><?php echo e(Session::get('flash_message')); ?></h3>
                </div>
                <?php endif; ?>

                </div>

                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-head" style="font-weight:600;">
                            <tr>
                                <td>S/N</td>
                                <td>Commenter</td>
                                <td style="width: 40%;">Body</td>
                                <td>Commented On</td>
                                <td>Author</td>
                                <td>Status</td>
                                <td style="width: 10%;">Action</td>

                            </tr>
                        </thead>
                        <tbody>

                            <?php  $sn = 1;?>
                            <?php if($comments->count() >0): ?>
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($sn++); ?></td>
                                                <td><?php echo e($comment->User->name); ?></td>
                                                <td><?php echo e(str_limit(($comment->body), 50)); ?></td>
                                                <td><?php echo e($comment->Episode->title); ?></td>
                                                <td><?php echo e($comment->Episode->Series->User->name); ?></td>
                                                <td>
                                                    <?php if($comment->approved == 0): ?>
                                                        Unapproved
                                                    <?php else: ?>
                                                        Approved
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(Route('adCommentsDetail', $comment->id)); ?>" class="btn btn-info mb-2" target="_new">Detail</a>
                                                    <?php if($comment->approved == 0): ?>
                                                        <form action="/admin/comments/aprove/<?php echo e($comment->id); ?>" method="post">
                                                            <?php echo method_field('PATCH'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit" name="aprove" id="appcombtn" class="btn btn-primary" value="Aprrove comment">
                                                        </form>
                                                    <?php else: ?>
                                                        <form action="/admin/comments/unaprove/<?php echo e($comment->id); ?>" method="post">
                                                            <?php echo method_field('PATCH'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="submit" name="unaprove" id="appcombtn" class="btn btn-danger" value="Dissaprrove comment">
                                                        </form>
                                                    <?php endif; ?>

                                                    <form action="/admin/comments/remove/<?php echo e($comment->id); ?>" method="post">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <input type="submit" name="delete" id="deletecombtn" class="btn btn-danger mt-2" value="Delete">
                                                    </form>

                                                </td>

                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e($comments->links()); ?>

                            <?php else: ?>

                                <h3 class="text-center text-danger py-5">No Series Available currently</h3>

                            <?php endif; ?>



                        </tbody>





                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
























<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>