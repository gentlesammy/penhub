<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    <h2> Rating Detail</h2>


                </div>

                <div class="card-body py-5">
                <h4 class="text-center text-primary"><?php echo e($rating->title); ?></h4>
                <p class="text-md-center text-black-50"><?php echo e($rating->description); ?></p>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravelprojects\penhub\resources\views/admin/ratings/view.blade.php ENDPATH**/ ?>