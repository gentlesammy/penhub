<div class="navbar">
    <ul class="nav">

    <li><a href="{{Route('about')}}">About</a></li>
        <li><a href="{{Route('blogserieshome')}}">Series</a></li>
        <li><a href="{{Route('blogEpisodehome')}}">Episodes</a></li>
        <li><a href="{{Route('writeforus')}}">Write for Us </a></li>
        <li><a href="{{Route('contact')}}">Contact</a></li>
    </ul>
    <div class="sociallink">

    </div>
</div>
