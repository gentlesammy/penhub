@extends('layouts.app')

@section('content')
<div class="container">
    HELLO
</div>
@endsection
