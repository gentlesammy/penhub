@extends('layouts.blog')
@section('title', 'Penhub: WRITE FOR US')











@section('content')
    <h1>WRITE FOR US</h1>
@endsection
