<template>
    <div>
        <a href="#" class="btnone" id="followseries">Follow</a>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
