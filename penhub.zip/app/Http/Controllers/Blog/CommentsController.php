<?php

namespace App\Http\Controllers\Blog;
use App\Comments;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    public function index(){

    }

    public function delete(){

    }


    public function update(){

    }




}
